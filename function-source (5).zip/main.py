import googleapiclient.discovery
from datetime import datetime, date, timedelta
import time
import logging
from google.auth import exceptions, default

# Configure logging
logging.basicConfig(level=logging.INFO)

# Fetch project ID dynamically using default credentials
credentials, project_id = default()
region = 'us-central1'  # Desired region for storage
DRY_RUN = False  # Set to False to actually create machine images

# Updated list of instances to process
instances_to_process = [
    {'name': 'onedios-app-cron-server', 'zone': 'asia-south1-a'},
    {'name': 'onedios-app-dev', 'zone': 'asia-south1-b'},
    {'name': 'onedios-app-new', 'zone': 'asia-south1-b'},
    {'name': 'onedios-openvpn', 'zone': 'asia-south1-a'},
    {'name': 'onedios-qa', 'zone': 'asia-south1-a'}    
]

def create_machineimage(event, context):
    """Triggered via Pub/Sub to create machine images from instances."""
    try:
        # Initialize the compute client
        compute = googleapiclient.discovery.build('compute', 'v1', credentials=credentials)

        # Current and previous date
        now = datetime.now()
        today = now.strftime("%Y%m%d")
        yesterday = (date.today() - timedelta(days=1)).strftime('%Y%m%d')

        # Process each instance
        for instance_data in instances_to_process:
            instance_name = instance_data['name']
            zone = instance_data['zone']
            instance_url = f'projects/{project_id}/zones/{zone}/instances/{instance_name}'

            # Prepare the request body for machine image creation
            body = {
                'name': f'{instance_name}-{today}',
                'source_instance': instance_url,
                'storageLocations': [region]  # Desired region for storage
            }

            if not DRY_RUN:
                # Actual machine image creation
                operation = compute.machineImages().insert(project=project_id, body=body).execute()
                logging.info(f"Machine image creation started for {instance_name} in {zone} (Stored in {region})")
                time.sleep(5)
            else:
                # Dry run, just log the action
                logging.info(f"DRY RUN: Would create machine image for {instance_name} in {zone} (Stored in {region})")

    except googleapiclient.errors.HttpError as e:
        logging.error(f"HTTP error: {e}")
        return f"HTTP error: {e}", 500
    except exceptions.GoogleAuthError as e:
        logging.error(f"Authentication failed: {e}")
        return f"Authentication failed: {e}", 500
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        return f"Unexpected error: {e}", 500

    return "Machine image creation function executed successfully.", 200
