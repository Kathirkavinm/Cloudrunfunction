from google.cloud import compute_v1
from google.auth import exceptions, default
from datetime import datetime, timezone, timedelta
import base64
import logging
import re

# Configure logging
logging.basicConfig(level=logging.INFO)

# Fetch Project ID Dynamically
credentials, project_id = default()

# Retention Policy (in days)
RETENTION_DAYS = 3  # Change as needed

# DRY_RUN Mode (Set to False to actually delete machine images)
DRY_RUN = False  

# Regex pattern for machine image names (e.g., "instance-20240206")
MACHINE_IMAGE_PATTERN = re.compile(r"^[a-zA-Z0-9_-]+-\d{8}$")


def delete_old_machine_images(event, context):
    """Triggered via Pub/Sub to delete machine images older than RETENTION_DAYS."""
    
    logging.info("Delete Old Machine Images function triggered.")

    try:
        # Decode the Pub/Sub message (if any)
        if 'data' in event:
            message = base64.b64decode(event['data']).decode('utf-8')
            logging.info(f"Received Pub/Sub message: {message}")

        compute_client = compute_v1.MachineImagesClient()
        now = datetime.now(timezone.utc)
        cutoff_date = now - timedelta(days=RETENTION_DAYS)

        images_list = compute_client.list(project=project_id)

        for image in images_list:
            if MACHINE_IMAGE_PATTERN.match(image.name):
                creation_time = datetime.strptime(image.creation_timestamp, "%Y-%m-%dT%H:%M:%S.%f%z")

                if creation_time < cutoff_date:
                    logging.info(f"Eligible for deletion: {image.name} (Created: {image.creation_timestamp})")

                    if not DRY_RUN:
                        compute_client.delete(project=project_id, machine_image=image.name)
                        logging.info(f"Deleted machine image: {image.name}")
                    else:
                        logging.info(f"DRY RUN: Would delete {image.name}")
                else:
                    logging.info(f"Skipping {image.name} (Recent: {image.creation_timestamp})")
            else:
                logging.info(f"Skipping {image.name} (Does not match pattern)")

        return "Machine image deletion function executed successfully.", 200

    except exceptions.GoogleAuthError as e:
        logging.error(f"Authentication failed: {e}")
        return f"Authentication failed: {e}", 500
    except Exception as e:
        logging.error(f"Error: {e}")
        return f"Error: {e}", 500
